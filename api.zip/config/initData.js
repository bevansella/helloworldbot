db.ReplyMessages.create({ contents: 'test', type: 'text' , replyToken: 'fake replyToken', sourceType: 'user', sourceId: '123'});
